Node Modules for this project have been excluded from the zip file due to their size, make sure to run "npm install" before starting this application
