
const query = require('querystring');
const http = require('http'); // http module
const url = require('url'); // url module
const responseHandler = require('./responses.js');

const port = process.env.PORT || process.env.NODE_PORT || 3000;

const urlStruct = {
    GET: {
        '/': responseHandler.getIndex,
        '/styles.css': responseHandler.getCSS,
        '/getUsers': responseHandler.getUsers,
        '/getGame': responseHandler.getGame,
        '/tick': responseHandler.tickPlayer,
        notFound: responseHandler.notFound,
      },
      HEAD: {
        '/getUsers': responseHandler.headUsers,
        '/notReal': responseHandler.headNotReal,
        notFound: responseHandler.notFound,
      },
      POST: {
        '/addUser': responseHandler.addUser,
        '/updateUser':responseHandler.updateUser,
        notFound: responseHandler.notFound,
      },
};

const onRequest = (request, response) => {
    const parsedUrl = url.parse(request.url);
    const method = request.method;
  
    if (!urlStruct[request.method]) {
      return urlStruct.HEAD.notFound(request, response);
    }
    // If it's a head/get request don't bother with parameters just call the method
    if (request.method === 'POST') {
      const body = [];
      request.on('error', () => {
        response.statusCode = 400;
        return response.end();
      });
  
      request.on('data', (chunk) => {
        body.push(chunk);
      });
  
      request.on('end', () => {
        const bS = Buffer.concat(body).toString();
        // Once we have the bodyParams object, we will call the handler function. We then
        // proceed much like we would with a GET request.
        return urlStruct[request.method][parsedUrl.pathname](request, response, bS);
      });
      
    } else if (urlStruct[request.method][parsedUrl.pathname]) {
      if(parsedUrl.search){
        //If there are parameters
        const urlParams = new URLSearchParams(parsedUrl.search);
        //If one of thsoe parameters is "claim"
        if(urlParams.get('name')){
          const name = urlParams.get('name');
          //This means its a lifecycle method, specifically tick
          //Update the counter
          return urlStruct[request.method][parsedUrl.pathname](request, response,urlParams.get('name'));
        }
      }
      return urlStruct[request.method][parsedUrl.pathname](request, response);
    } else {
      return urlStruct.GET['/'](request, response);
    }
  
    return 1;
  };

  http.createServer(onRequest).listen(port, () => {
    console.log(`Listening on 127.0.0.1:${port}/`);
  });