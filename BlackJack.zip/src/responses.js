let ticks = 0;

const users = {
    "dealer":{
    hand:[1,3],
    decision: "stand",
    chips: 10000,
    bet: 0,
    tick: 100000,
    name: "dealer"},


};
//When A player exits add them/ their name to past users (does this need I/O?)
const pastUsers = {};
//If the deck runs out, go into second deck 
let deck = [];


const { debug } = require('console');
const fs = require('fs'); // pull in the file system module
const { request } = require('http');

const index = fs.readFileSync(`${__dirname}/../client/index.html`);
const css = fs.readFileSync(`${__dirname}/../client/styles.css`);
const game = fs.readFileSync(`${__dirname}/../client/game.html`);

const respondJSON = (request, response, status, object) => {
    response.writeHead(status, { 'Content-Type': 'application/json' });
    response.write(JSON.stringify(object));
    response.end();
  };

const respond = (request, response, content, type, code) => {
    // set status code (200 success) and content type
    response.writeHead(code, { 'Content-Type': type });
    // write the content string or buffer to response
    response.write(content);
    // send the response to the client
    response.end();
};

const updateUser = (request,response,player) => {
    //"Player" is a json object that came with the post request
    //However because of the concatenation it is currently a string
    //Recompile it to make it parsable again
    const jsonPlayer= JSON.parse(player);
    //Json player is created from a client side secret player
    //its ticks are not updated
    //So when we overwrite it will end up thinking its ticks are like 3 or 4 and delete it
    //Solution: since the very fact that they are sending a request proves they are here, set the ticks to the current server tick
    jsonPlayer.tick = ticks;

    //You can only update a user that is here
    if(users[jsonPlayer.name] != null){
        users[jsonPlayer.name] = jsonPlayer;
    };
    //Also every time an update is sent, check if turn should now be activated
    const keys = Object.keys(users);
    let startTurn = true;
    for(let k of keys){
        
        if(users[k].decision == "unready" || users[k].decision == "undecided"){
            //This will run if there is anyone undecided
            startTurn = false;
        }
    }
    //If everyone is ready for the next hand or currently in a hand this runs
    if(startTurn){
        if(users["dealer"].decision == "ready"){
            //This means its a new hand (the dealer is basically a constant so use it as base)
            //Bets and decisions were already cleared, chips are handled client side and names are constant
            for(let k of keys){
                users[k].hand = [];
                users[k].decision = "undecided";
            }
            users["dealer"].decision = "stand"
            
            firstTurn();
        }else{
            turn();
        }
    }

    const responseJSON = {
        users,
      }
      respondJSON(request,response,200,responseJSON);
};

const getCSS = (request, response) => respond(request, response, css, 'text/css', 200);

const getIndex = (request, response) => respond(request, response, index, 'text/html', 200);

const getUsers = (request, response) => {
    const responseJSON = {
      users,
    }
    respondJSON(request,response,200,responseJSON);
};

const shuffle = () =>{
    //Order: Diamond, Heart, Spade, Clover (meaning 13 is the Diamond king while 52 is the clover king)
const perfectDeck = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37
,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52];
const resultDeck = [];
//Returns between
for(let i = 52;i>0;i--){ 
    //start at 52, get to 1
    const index = Math.floor(Math.random()* i);
    //Each iteration, remove one random item from an array and shorten the array
    resultDeck.push(perfectDeck[index]);
    perfectDeck.splice(index,1);
}
return resultDeck;
}

const draw = (arr) =>{
    //First change the nextCard object, then return what the nextCard object WAS, not what it is
    //Don't draw from an empty deck (rare problem)
    if(!deck.length){
        deck = shuffle();
    };

    arr.push(deck.pop())
}

//First turn is called at the start of each hand
//All the players hands are populated with 2 cards
const firstTurn = () => {
    const keys = Object.keys(users);
    for(let k of keys){
        draw(users[k].hand);
        draw(users[k].hand);
    }
}


//Turn only happens when all players are ready (this should be handled in a heartbeat method), the first thing that happens is the player
//That joined earliest has their move (hit/stand) played, then the 2nd earliest ....
//The server contains a copy of the players + their hands to make this easier
//The "users" object contains keys of all the players names with 4 attributes
//1. Their hand (array)
//2. Their decision (hit/stand/undecided/bust/unclaimed, string)
//3. Their chips total, number
//4. Their current bet, number
const turn = () => {
const keys = Object.keys(users);
let allDone = true;
for(let k of keys){
    if(k != "dealer"){
    if(users[k].decision === "hit"){
        allDone = false;
        draw(users[k].hand);
        if(sum(users[k].hand)> 21){
            //If they bust, refuse future decisions (stand does the same thing but bust is needed for payout decisions later)
            users[k].decision = "bust";
            //DON'T erase their hand, they (and other players) should be able to see what happened, erase after all players have busted/won
        }else{
        //Only reset the decisions of people who hit and dont bust, people who stand must remain standing, do not allow alterations to stand or bust decisions
        users[k].decision = "undecided";
        }
    }
}
    
}
    //If no players hit, it's now the dealers turn
    if(allDone){
        //The dealer will always start out with two cards but one is show
        while(sum(users["dealer"].hand) < 17){
            draw(users["dealer"].hand);
        }

        const dealerSum = sum(users["dealer"].hand);
        
        //The dealers hand is now 17 or above, check against all players
        for(let k of keys){
            if(users[k].decision !== "bust"){
                if(dealerSum > 21){
                    
                    users[k].chips += parseInt(users[k].bet) * 2;
                    users["dealer"].chips -= parseInt(users[k].bet);
                    users[k].bet = 0;
                }else{
                const playerSum = sum(users[k].hand)
                if(playerSum > dealerSum){
                    //They won the bet
                    
                    users[k].chips += parseInt(users[k].bet) * 2;
                    users["dealer"].chips -= parseInt(users[k].bet);
                    users[k].bet = 0;
                }else if(playerSum == dealerSum){
                    
                    users[k].chips +=parseInt(users[k].bet);
                    users[k].bet = 0;
                    //They tied, no payout
                }else{
                    //They lost
                    
                    users["dealer"].chips += parseInt(users[k].bet);
                    users[k].bet = 0;
                }
            }
            }else{
                //They busted early, erase their bet
                users["dealer"].chips += users[k.bet];
                users[k].bet = 0;
            }
            
            //Now that its over theyre in between rounds
            users[k].decision = "unready";
        }
        //At the end the dealer is ready for another hand
        users["dealer"].decision = "ready";
        //Do not erase their hand! again, players want to see what happened
        //Now allow them to qeueu up for the next hand
    }else{
        //This is triggered every time a player hits, now if a player hits and busts, then they will NOT be undecided
        //If there are no undecideds left it must all be stands/busts
        //This is really just a contingency clause for the situation described below
        let goAgain = true;
        //If it is not all done still check that not all the players that have hit have busted 
        //this would cause a softlocked website because no players can send changes to their requests so no turn checks happen anymore
        for(let k of keys){
            if(users[k].decision == "undecided"){
                goAgain = false;
            }
        }

        if(goAgain){
            turn();
        }
    }
    //After this runs, all the logic will have been handled, all users will have their 
    //Hands/Bets/Totals/Decisions fixed

}
const sum = (arr) =>{
    let result = 0;
    const l = arr.length
    for(let i=0;i<l;i++){
        //This needs to be done as a player may 
        let realValue = arr[i];
        while(realValue > 13){
            realValue -= 13;
        }

        if(realValue>9){
            realValue = 10;
        }
        result+=realValue;
    }
    
    return result;
}

const getGame = (request,response,name) => {
    //Send the game html altered to contain their name in a secret block
    respond(request,response,game,'text/html',200);
}

const tickPlayer = (request,response,name) => {
    //This shouldn't be a get method but it's just an increment so I'm bending the rules a little
    let user = users[name];
    user.tick += 1;
    const responseJSON = {
        users,
      }
      respondJSON(request,response,200,responseJSON);
}

const serverLoop = () => {
    //Loop is for kicking players out, it is on the same frequency as the lifecycle methods so should a player fall behind by a 
    //Really long time it will kick them out
    setTimeout(serverLoop,500);
    ticks++;
    const keys = Object.keys(users);
    for(let k of keys){
        if(ticks - users[k].tick > 10){
            removeUser(k);
        }
    }
}

const addUser = (request, response, name) => {
    if(Object.keys(users).length = 1){
        //This is the first user added, start a timer
        serverLoop();
        //Each time a user is added, its personal "ticks" is set to the server ticks
        //The player's tick is incremented with its lifecycle methods
        //Should it fall more than 4 seconds behind it will assume the player no longer exists and erase them
    }

    if (!name ) {
      const responseJson = {
        message: 'Name is required',
      };
      //return respond(request, response, JSON.stringify(responseJson), 'application/json', 400);
      return respond(request,response,index,'text/html',200);
    }
  
    // change to make to user
    // This is just a dummy object for example
    const newUser = {
      name: name,
      chips: 500,
      bet:0,
      decision:"undecided",
      hand:[],
      tick: ticks
    };
    // modifying our dummy object
    // just indexing by time for now
  
    if (users[newUser.name] != null) {
      // If someone with the name already exists, send back failure
      const responseJson = {
        message: 'Player is already in the game',
      };
      //return respond(request, response, JSON.stringify(responseJson), 'application/json', 400);
      return respond(request,response,index,'text/html',200);
    }
    // If they don't, it'll create one so respond 201
    //They should start with 2 cards so make them draw

    draw(newUser.hand);
    draw(newUser.hand);
    users[newUser.name] = newUser;
    // return a 201 created status and the html file for the game
    return respond(request,response,game,'text/html',201);
  };

  const removeUser = (name) =>{
    const user = users[name];
    //Is a property a reference? will deleting it  delete it in both arrays?
    const oldUser = {
        name: user.name,
        chips: user.chips,
        bet: 0,
        decision:"undecided",
        hand:[],
        tick: 0,
      };
    delete(users[name]);
    pastUsers[name] = oldUser;
  }

module.exports = {
    getCSS,
    getIndex,
    draw,
    addUser,
    getUsers,
    getGame,
    updateUser,
    removeUser,
    tickPlayer,
}